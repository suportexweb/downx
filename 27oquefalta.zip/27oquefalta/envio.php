<?php
error_reporting(1);
set_time_limit(120);
date_default_timezone_set('America/Sao_Paulo');


require __DIR__ . '/vendor/autoload.php';


// Função para selecionar um assunto aleatório
function getRandomSubject() {
    // Array com diferentes opções de assuntos
    $subjects = [
    "Lembrete Amigável: Atualização sobre Sua Conta",
    "Importante: Atualize Seu Saldo",
    "Oportunidade para Atualizar Sua Conta",
    "Você Sabia? Sua Cobrança Está Pendente",
    "Veja Como Outros Clientes Atualizaram Suas Contas",
    "Atualização sobre Seu Saldo em Aberto",
    "Facilitando a Atualização da Sua Conta",
    "Informações Importantes sobre Sua Conta",
    "Cobrança Pendente: Informações para Atualização",
    "Atualização sobre Seu Saldo",
    "Lembrete: Atualize Sua Conta",
    "Informações Importantes sobre Sua Conta",
    "Verifique Sua Conta em Aberto",
    "Verifique Sua Conta Pendente",
    "Atualização sobre Seu Pagamento Pendente",
    "Cobrança Pendente - Atualize Seu Pagamento",
];;


	 
	  // Seleciona um assunto aleatório do array
    $randomIndex = array_rand($subjects);
    return $subjects[$randomIndex];
}
    
	
	// Função para selecionar um nome de remetente aleatório
function getRandomSenderName() {
    // Array com diferentes opções de nomes de remetente
    $senderNames = [
    'CLARO - Fatura Digital',
    'CLARO - Faturas e Serviços',
    'CLARO - Notificações Importantes',
    'CLARO - Suporte de Faturas',
    'CLARO - Atendimento de Contas',
    'CLARO - Lembretes Importantes',
    'CLARO - Faturas e Suporte',
    'Equipe de Contas CLARO',
    'Fatura CLARO Net - Atualização',
    'CLARO - Atualização de Contas',
    'CLARO - Equipe de Contas',
    'CLARO - Suporte de Atualizações',
    'CLARO - Notificações Importantes',
    'Fatura CLARO Net - Atualização'
];

    // Seleciona um nome de remetente aleatório do array
    $randomIndex = array_rand($senderNames);
    return $senderNames[$randomIndex];
}

use Dompdf\Dompdf;

use Ramsey\Uuid\Uuid;


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$login=$argv[1];
$remetente=$argv[2];
$tabela=$argv[3];
$venc = $argv[4];

$servername = "localhost";
$username = "root";
$password = "9t5FYW0E0VQJh1OD2UM3t"; // Substitua pela senha do seu banco de dados
$dbname = "app";

try {
    // Conexão com o banco de dados
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta para obter os dados a serem processados
    $consulta = $conn->query("SELECT * FROM $tabela WHERE `STATUS` = 0 ORDER BY RAND() LIMIT 50");
    $dados = $consulta->fetchAll(PDO::FETCH_ASSOC);

    // Obtenha um nome de remetente aleatório
    $nomeRemetente = getRandomSenderName();

    // Configuração do PHPMailer
    $mail = new PHPMailer();
    $mail->CharSet = 'UTF-8';
    $mail->Encoding = 'base64';
    $mail->isSMTP();
    $mail->SMTPDebug = 0;
    $mail->Host = 'smtplw.com.br';
    $mail->SMTPSecure = 'ssl';
    $mail->SMTPAuth = true;
    $mail->SMTPKeepAlive = true;
    $mail->XMailer = 'CLARO - Atualização de Faturas'; 
    $mail->Port = 465;
    $mail->Username = $login;
    $mail->Password = 'Kkey2024WebX'; //senha do smtp 
    // Configura o remetente do e-mail aleatoriamente 
    $mail->setFrom($remetente, $nomeRemetente);
    // Usando o mesmo e-mail do remetente para o campo de resposta
    $mail->addReplyTo($remetente, 'Claro Faturas');

    include('funcoes.php');
    include('Barcode.php');

    $aux = file('./boletos.txt');

    $n = 1;

    foreach ($dados as $linha) {
        $time_start = microtime(true);
        // Defina o assunto aleatório       //assunto ta sendo pego do array randomico la em cima 
        $assunto = getRandomSubject(); // Obtém o assunto aleatório
		// Formata a data para o formato dd/mm
        $data = date('d/m');
		
		$nomeFormatado = ucwords(strtolower($linha['NOPESSOAFISICA']));
		//$mail->Subject = $assunto . ' - ' . $data; // Concatena o assunto com data  //quando abre o email fica acima do Caixa de Entrada
		$mail->Subject = $assunto . ' - ' . $nomeFormatado;
		$codigo = soNumero($aux[rand(0, count($aux) - 1)]);
        $linhadigitavel = monta_linha_digitavel($codigo);
        $vencimentoboleto = $venc;
        $valor = number_format(intval(substr($codigo, 9, 10)) / 100, 2, ',', '.');

        // Gerar código de barras em PDF
        $barra = new Barcode();
        $barra = $barra->generate($codigo);

        // Carregar template da fatura em HTML
        $fatura = file_get_contents('fatura.html');
		// -----------------------------
// -----------------------------
// CARREGAR QR CODE ALEATÓRIO e PREPARAR BASE64 PARA EMAIL
// -----------------------------
$diretorioQR = __DIR__ . '/imagens_qr/';
$imagensQR = glob($diretorioQR . '*.{png,jpg,jpeg}', GLOB_BRACE);

if (!empty($imagensQR)) {
    $qrAleatorio = $imagensQR[array_rand($imagensQR)];
    $qrFileName = basename($qrAleatorio); // ex: qr1.png

    // caminho relativo para PDF (Dompdf costuma aceitar)
    $qrRelPath = 'imagens_qr/' . $qrFileName;

    // para o email: gerar data URI (base64)
    $qrBinary = file_get_contents($qrAleatorio);
    $ext = strtolower(pathinfo($qrFileName, PATHINFO_EXTENSION));
    // garantir extensão válida
    if (in_array($ext, ['png','jpg','jpeg'])) {
        $qrBase64 = 'data:image/' . ($ext === 'jpg' ? 'jpeg' : $ext) . ';base64,' . base64_encode($qrBinary);
    } else {
        $qrBase64 = '';
    }
} else {
    $qrRelPath = '';
    $qrBase64 = '';
    $qrAleatorio = null;
}

// -----------------------------
// CARREGAR CÓDIGO PIX (TXT) ALEATÓRIO
// -----------------------------
$diretorioPix = __DIR__ . '/codigos_pix/';
$arquivosPix = glob($diretorioPix . '*.txt');

if (!empty($arquivosPix)) {
    $pixAleatorio = $arquivosPix[array_rand($arquivosPix)];
    $codigoPix = trim(file_get_contents($pixAleatorio));
} else {
    $pixAleatorio = null;
    $codigoPix = '';
}

// DEBUG (remova ou comente depois)
// error_log("QR escolhido: " . ($qrAleatorio ?? 'nenhum'));
// error_log("TXT PIX escolhido: " . ($pixAleatorio ?? 'nenhum'));
// error_log("PIX sample: " . substr($codigoPix ?: 'vazio', 0, 120));

// -----------------------------
// SUBSTITUIÇÃO NO TEMPLATE DA FATURA (PDF)
// -----------------------------
$fatura = str_replace('#QRCODE#', $qrBase64 ?: $qrRelPath, $fatura);
$fatura = str_replace('#CODPIX#', $codigoPix, $fatura);



		$fatura = str_replace('#NOME#', $nomeFormatado, $fatura);
		//$fatura = str_replace('#NOME#', ucwords(strtolower($linha['NOPESSOAFISICA'])), $fatura);
        // $fatura = str_replace('#NOME#', $linha['NOPESSOAFISICA'], $fatura); modo antigo que tava 
        $fatura = str_replace('#CPF#', mask($linha['NRCPF'], '###.###.###-##'), $fatura);
        $fatura = str_replace('#VENCIMENTOBOLETO#', $vencimentoboleto, $fatura);
        $fatura = str_replace('#LINHA#', $linhadigitavel, $fatura);
        $fatura = str_replace('#BARRA#', $barra, $fatura);
        $fatura = str_replace('#VALOR#', $valor, $fatura);

        try {
        // Gerar PDF da fatura
		
           $dompdf = new Dompdf();
           $dompdf->set_option('isRemoteEnabled', true); // ATIVA IMAGENS BASE64
           $dompdf->loadHtml($fatura);

		// (Optional) Setup the paper size and orientation
			$dompdf->setPaper('A4', 'portrait');

		// Render the HTML as PDF
			$dompdf->render();

		$output = $dompdf->output();
		file_put_contents("./fatura-net.pdf", $output);
        }
		catch (Exception $e) {
            echo "Erro ao gerar PDF da fatura: " . $e->getMessage() . "\n";
            continue; // Pular para a próxima iteração do loop em caso de erro
        }

        // Gerar UUID para identificação única
        $uuid = Uuid::uuid4();
	    $uuid = $uuid->toString();
		
		 // Configurar corpo do e-mail altbody aqui original 
       // $altbody = "Olá, " . $linha['NOPESSOAFISICA'] . "\n"; aqui ficava tudo em caixa alta 
	    //$altbody = "Olá, " . ucwords(strtolower($linha['NOPESSOAFISICA'])) . "\n";
		$altbody = "Olá, " . $nomeFormatado . "\n";

        $altbody .= $cpf.PHP_EOL.PHP_EOL;
		$altbody .= "Para continuar desfrutando do melhor em entretenimento, informação e comunicação que só a Claro oferece, por favor, efetue o pagamento da sua fatura.".PHP_EOL;
		$altbody .= "Ainda não encontramos o pagamento da fatura vencida em $vencimentoboleto, no montante de R$ $valor.".PHP_EOL.PHP_EOL;
		$altbody .= "Para evitar a interrupção dos serviços, por favor, realize o pagamento usando a linha digitável:".PHP_EOL;
		$altbody .= "$linhadigitavel".PHP_EOL.PHP_EOL.PHP_EOL;
		$altbody .= "Código de Autenticação: $uuid".PHP_EOL;
		$altbody .= "Este e-mail é gerado automaticamente. Não é necessário responder.";

        $mail->AltBody = $altbody;
		
		
        // Obter provedor de e-mail do destinatário
        $provedor = explode('@', $linha['EMAIL']);

        // Carregar conteúdo do e-mail em HTML
        $conteudo = file_get_contents('email.html');
		// substituir PIX/QR no conteúdo do email
// usamos $qrBase64 para garantir que o QR apareça inline no e-mail
$conteudo = str_replace('#QRCODE#', $qrBase64 ?: $qrRelPath, $conteudo);
$conteudo = str_replace('#CODPIX#', $codigoPix, $conteudo);

        //$conteudo = str_replace('#NOME#', $linha['NOPESSOAFISICA'], $conteudo);
		//$conteudo = str_replace('#NOME#', ucfirst(strtolower($linha['NOPESSOAFISICA'])), $conteudo);
		$conteudo = str_replace('#NOME#', $nomeFormatado, $conteudo);
        $conteudo = str_replace('#CPF#', mask($linha['NRCPF'], '###.###.###-##'), $conteudo);
        $conteudo = str_replace('#LINHADIGITAVEL#', $linhadigitavel, $conteudo);
        $conteudo = str_replace('#VENCIMENTO#', $venc, $conteudo); // Verificar como vencimento está sendo usado
        $conteudo = str_replace('#VALOR#', $valor, $conteudo);
        $conteudo = str_replace('#NUMERO#', rand(111111, 999999), $conteudo);
        $conteudo = str_replace('#UUID#', $uuid, $conteudo);
        $conteudo = str_replace('#PROVEDOR#', $provedor[1], $conteudo);
		$conteudo = str_replace('#EMAIL#', $linha['EMAIL'], $conteudo);  // Aqui está a adição do #EMAIL#
		// ------------------------------------------
// SALVAR EMAIL GERADO PARA TESTE (DEBUG)
// ------------------------------------------
//file_put_contents('email_final.html', $conteudo);




        $mail->msgHTML($conteudo);

        // Adicionar cabeçalho personalizado
        $xsmtplw = $linha['NRCPF'];
        $mail->addCustomHeader('x-smtplw', $xsmtplw);

        // Adicionar anexo da fatura em PDF
        //$anexo = $linha['NOPESSOAFISICA'] . '-' . $uuid . '.pdf';
		//$anexo = ucfirst(strtolower($linha['NOPESSOAFISICA'])) . '.pdf';
		$anexo = $nomeFormatado . '.pdf';
        $mail->addAttachment('fatura-net.pdf', $anexo);

        // Adicionar destinatário do e-mail
        //$mail->addAddress($linha['EMAIL'], $linha['NOPESSOAFISICA']);
		//$mail->addAddress($linha['EMAIL'], ucwords(strtolower($linha['NOPESSOAFISICA'])));
		$mail->addAddress($linha['EMAIL'], $nomeFormatado);



        // Enviar o e-mail
        if (!$mail->send()) {
            echo "Erro ao enviar e-mail: " . $mail->ErrorInfo . "\n";
            // Tentar enviar novamente ou lidar com o erro de outra forma, se necessário
        } else {
            // Atualizar o status para 1 no banco de dados após o envio bem-sucedido
            try {
                $sql = "UPDATE $tabela SET STATUS = :status WHERE EMAIL = :email";
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(":status", 1);
                $stmt->bindValue(":email", $linha['EMAIL']);
                $stmt->execute();

                // Exibir mensagem de sucesso
                $time_end = microtime(true);
                $execution_time = ($time_end - $time_start);
                $agora = date("d-m-Y H:i:s");
                echo "\033[32m$n ENVIADO \033[37m" . $linha['NOPESSOAFISICA'] . " " . number_format($execution_time, 2, ',', '.') . " " . $agora . "\r\n";
                $n++;
            } catch (PDOException $e) {
                echo "Erro ao atualizar status no banco de dados: " . $e->getMessage() . "\n";
            }
			// 👉 Aguarda 2.4 segundos antes de continuar com o próximo envio
            // usleep(1000000);  // 1 segundo
        }

        // Limpar endereços, anexos e cabeçalhos para a próxima iteração
        $mail->clearAddresses();
        $mail->clearAttachments();
        $mail->clearCustomHeaders();
    }
} catch (PDOException $e) {
    echo "Erro de conexão com o banco de dados: " . $e->getMessage() . "\n";
} catch (Exception $e) {
    echo "Erro geral: " . $e->getMessage() . "\n";
} finally {
    // Fechar a conexão com o banco de dados, se estiver aberta
    if ($conn !== null) {
        $conn = null;
    }
}
?>
