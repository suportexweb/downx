<?php
// send.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/vendor/autoload.php';

$response = [
    'total'   => 0,
    'sent'    => 0,
    'failed'  => 0,
    'results' => []
];

function finishAndExit(array $resp) {
    echo json_encode($resp, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // =========================
    // 1) LER DADOS DO POST
    // =========================
    $host       = trim($_POST['smtp_host']  ?? '');
    $port       = (int)($_POST['smtp_port'] ?? 0);
    $secure     = trim($_POST['smtp_secure'] ?? 'none'); // 'none', 'tls', 'ssl'
    $user       = trim($_POST['smtp_user']  ?? '');
    $pass       = $_POST['smtp_pass']       ?? '';
    $fromName   = trim($_POST['smtp_from_name']  ?? '');
    $fromEmail  = trim($_POST['smtp_from_email'] ?? '');
    $subject    = trim($_POST['subject'] ?? '');
    $message    = $_POST['message'] ?? '';
    $delayMs    = (int)($_POST['smtp_delay'] ?? 0);  // milissegundos

    if ($fromEmail === '') {
        $fromEmail = $user;
    }

    if ($host === '' || $port <= 0 || $user === '' || $pass === '') {
        $response['results'][] = [
            'index'   => 0,
            'email'   => '',
            'status'  => 'error',
            'message' => 'Configuração SMTP incompleta (host/porta/usuário/senha).'
        ];
        finishAndExit($response);
    }

    if ($subject === '' || trim($message) === '') {
        $response['results'][] = [
            'index'   => 0,
            'email'   => '',
            'status'  => 'error',
            'message' => 'Assunto ou mensagem vazios.'
        ];
        finishAndExit($response);
    }

    // =========================
    // 2) LER clientes.txt
    // =========================
    $filePath = __DIR__ . '/clientes.txt';
    if (!is_file($filePath)) {
        $response['results'][] = [
            'index'   => 0,
            'email'   => '',
            'status'  => 'error',
            'message' => 'Arquivo clientes.txt não encontrado na pasta do sistema.'
        ];
        finishAndExit($response);
    }

    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    $clientes = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '#') === 0) {
            continue;
        }

        $parts = explode(';', $line);
        $parts = array_map('trim', $parts);
        $parts = array_pad($parts, 5, '');

        [$nome, $cpf, $email, $numero, $protocolo] = $parts;

        if ($email === '') {
            continue;
        }

        $clientes[] = [
            'nome'      => $nome,
            'cpf'       => $cpf,
            'email'     => $email,
            'numero'    => $numero,
            'protocolo' => $protocolo,
        ];
    }

    if (empty($clientes)) {
        $response['results'][] = [
            'index'   => 0,
            'email'   => '',
            'status'  => 'error',
            'message' => 'Nenhum cliente válido encontrado em clientes.txt.'
        ];
        finishAndExit($response);
    }

    $response['total'] = count($clientes);

    // =========================
    // 3) CONFIGURAR PHPMailer UMA VEZ SÓ
    // =========================
    set_time_limit(0); // deixar rodar sem limite

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = $host;
        $mail->Port       = $port;
        $mail->SMTPAuth   = true;
        $mail->Username   = $user;
        $mail->Password   = $pass;

        if ($secure === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } elseif ($secure === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } // 'none' não seta criptografia

        // Timeout: se a Locaweb demorar demais, não trava pra sempre
        $mail->Timeout       = 20;      // segundos
        $mail->SMTPKeepAlive = true;    // reaproveita a conexão entre envios

        $mail->CharSet = 'UTF-8';

        // remetente padrão
        $mail->setFrom($fromEmail, $fromName ?: $fromEmail);
        $mail->addReplyTo($fromEmail, $fromName ?: $fromEmail);
    } catch (Exception $e) {
        $response['results'][] = [
            'index'   => 0,
            'email'   => '',
            'status'  => 'error',
            'message' => 'Erro ao configurar SMTP: ' . $e->getMessage()
        ];
        finishAndExit($response);
    }

    // =========================
    // 4) LOOP DE ENVIO
    // =========================
    $index = 0;

    foreach ($clientes as $cli) {
        $index++;

        $email = $cli['email'];
        $nome  = $cli['nome'];
        $cpf   = $cli['cpf'];
        $numero    = $cli['numero'];
        $protocolo = $cli['protocolo'];

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $response['failed']++;
            $response['results'][] = [
                'index'   => $index,
                'email'   => $email,
                'status'  => 'error',
                'message' => 'E-mail inválido no clientes.txt.'
            ];
            continue;
        }

        // Se não veio número/protocolo, gera na hora
        if ($numero === '' || $numero === '0') {
            $numero = (string) random_int(100000, 999999);
        }
        if ($protocolo === '') {
            $protocolo = strtoupper(bin2hex(random_bytes(3))); // ex: A1B2C3
        }

        // Substitui variáveis no corpo
        $body = str_replace(
            ['#NOME#', '#CPF#', '#NUMERO#', '#PROTOCOLO#'],
            [$nome, $cpf, $numero, $protocolo],
            $message
        );

        try {
            // Zera destinatários e anexos anteriores
            $mail->clearAddresses();
            $mail->clearAttachments();

            // Destinatário atual
            $mail->addAddress($email, $nome ?: $email);

            // Conteúdo
            $mail->Subject = $subject;
            $mail->Body    = $body;
            $mail->isHTML(true);

            $inicio = microtime(true);
            $ok = $mail->send();
            $fim = microtime(true);
            $tempo = number_format($fim - $inicio, 2, ',', '');

            if ($ok) {
                $response['sent']++;
                $response['results'][] = [
                    'index'   => $index,
                    'email'   => $email,
                    'status'  => 'success',
                    'message' => 'Enviado em ' . $tempo . 's'
                ];
            } else {
                $response['failed']++;
                $response['results'][] = [
                    'index'   => $index,
                    'email'   => $email,
                    'status'  => 'error',
                    'message' => $mail->ErrorInfo ?: 'Falha desconhecida ao enviar.'
                ];
            }
        } catch (Exception $e) {
            $response['failed']++;
            $response['results'][] = [
                'index'   => $index,
                'email'   => $email,
                'status'  => 'error',
                'message' => 'Exceção PHPMailer: ' . $e->getMessage()
            ];
        }

        // Delay entre envios (ms → microssegundos)
        if ($delayMs > 0) {
            usleep($delayMs * 1000);
        }
    }

    // Fecha a conexão SMTP
    $mail->smtpClose();

} catch (Throwable $e) {
    $response['results'][] = [
        'index'   => 0,
        'email'   => '',
        'status'  => 'error',
        'message' => 'Erro inesperado: ' . $e->getMessage()
    ];
}

finishAndExit($response);
