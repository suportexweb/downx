<?php
// send_stream.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php';

// ---------- CONFIG STREAMING ----------
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-cache');
header('X-Accel-Buffering: no'); // ajuda em alguns servidores (nginx)

@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', 0);
while (ob_get_level() > 0) {
    ob_end_flush();
}
ob_implicit_flush(true);

function sendEvent(array $data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE) . "\n";
    flush();
}

// ---------- LER POST ----------
$host       = trim($_POST['smtp_host']  ?? '');
$port       = (int)($_POST['smtp_port'] ?? 0);
$secure     = trim($_POST['smtp_secure'] ?? 'none');
$user       = trim($_POST['smtp_user']  ?? '');
$pass       = $_POST['smtp_pass']       ?? '';
$fromName   = trim($_POST['smtp_from_name']  ?? '');
$fromEmail  = trim($_POST['smtp_from_email'] ?? '');
$subject    = trim($_POST['subject'] ?? '');
$message    = $_POST['message'] ?? '';
$delayMs    = (int)($_POST['smtp_delay'] ?? 0);

if ($fromEmail === '') {
    $fromEmail = $user;
}

if ($host === '' || $port <= 0 || $user === '' || $pass === '') {
    sendEvent([
        'type'    => 'error',
        'index'   => 0,
        'email'   => '',
        'message' => 'Configuração SMTP incompleta (host/porta/usuário/senha).'
    ]);
    exit;
}

if ($subject === '' || trim($message) === '') {
    sendEvent([
        'type'    => 'error',
        'index'   => 0,
        'email'   => '',
        'message' => 'Assunto ou mensagem vazios.'
    ]);
    exit;
}

// ---------- LER clientes.txt ----------
$filePath = __DIR__ . '/clientes.txt';
if (!is_file($filePath)) {
    sendEvent([
        'type'    => 'error',
        'index'   => 0,
        'email'   => '',
        'message' => 'Arquivo clientes.txt não encontrado na pasta do sistema.'
    ]);
    exit;
}

$lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$clientes = [];

foreach ($lines as $line) {
    $line = trim($line);
    if ($line === '' || strpos($line, '#') === 0) continue;

    $parts = explode(';', $line);
    $parts = array_map('trim', $parts);
    $parts = array_pad($parts, 5, '');

    [$nome, $cpf, $email, $numero, $protocolo] = $parts;

    if ($email === '') continue;

    $clientes[] = [
        'nome'      => $nome,
        'cpf'       => $cpf,
        'email'     => $email,
        'numero'    => $numero,
        'protocolo' => $protocolo,
    ];
}

if (empty($clientes)) {
    sendEvent([
        'type'    => 'error',
        'index'   => 0,
        'email'   => '',
        'message' => 'Nenhum cliente válido encontrado em clientes.txt.'
    ]);
    exit;
}

$total  = count($clientes);
$sent   = 0;
$failed = 0;

// avisa o front que começou
sendEvent([
    'type'     => 'start',
    'total'    => $total,
    'delay_ms' => $delayMs
]);

set_time_limit(0);

// ---------- CONFIGURAR PHPMailer UMA VEZ ----------
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = $host;
    $mail->Port       = $port;
    $mail->SMTPAuth   = true;
    $mail->Username   = $user;
    $mail->Password   = $pass;

    if ($secure === 'tls') {
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    } elseif ($secure === 'ssl') {
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    }

    $mail->Timeout       = 20;      // evita travar pra sempre
    $mail->SMTPKeepAlive = true;    // reaproveita conexão

    $mail->CharSet = 'UTF-8';
    $mail->setFrom($fromEmail, $fromName ?: $fromEmail);
    $mail->addReplyTo($fromEmail, $fromName ?: $fromEmail);
} catch (Exception $e) {
    sendEvent([
        'type'    => 'error',
        'index'   => 0,
        'email'   => '',
        'message' => 'Erro ao configurar SMTP: ' . $e->getMessage()
    ]);
    exit;
}

// ---------- LOOP DE ENVIO STREAMING ----------
$index = 0;

foreach ($clientes as $cli) {
    $index++;

    $email     = $cli['email'];
    $nome      = $cli['nome'];
    $cpf       = $cli['cpf'];
    $numero    = $cli['numero'];
    $protocolo = $cli['protocolo'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $failed++;
        sendEvent([
            'type'    => 'item',
            'index'   => $index,
            'email'   => $email,
            'status'  => 'error',
            'message' => 'E-mail inválido no clientes.txt.'
        ]);
        continue;
    }

    if ($numero === '' || $numero === '0') {
        $numero = (string) random_int(100000, 999999);
    }
    if ($protocolo === '') {
        $protocolo = strtoupper(bin2hex(random_bytes(3)));
    }

    // delay ANTES do envio, do 2º em diante
    if ($index > 1 && $delayMs > 0) {
        usleep($delayMs * 1000);
    }

    $body = str_replace(
        ['#NOME#', '#CPF#', '#NUMERO#', '#PROTOCOLO#'],
        [$nome,   $cpf,    $numero,    $protocolo],
        $message
    );

    try {
        $mail->clearAddresses();
        $mail->clearAttachments();
        $mail->addAddress($email, $nome ?: $email);

        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->isHTML(true);

        $inicio = microtime(true);
        $ok = $mail->send();
        $fim = microtime(true);
        $tempo = number_format($fim - $inicio, 2, ',', '');

        if ($ok) {
            $sent++;
            sendEvent([
    'type'    => 'item',
    'index'   => $index,
    'email'   => $email,
    'status'  => 'success',
    'message' => 'OK'
]);

        } else {
            $failed++;
            sendEvent([
    'type'    => 'item',
    'index'   => $index,
    'email'   => $email,
    'status'  => 'error',
    'message' => $mail->ErrorInfo ?: 'Falha ao enviar'
]);

        }
    } catch (Exception $e) {
        $failed++;
        sendEvent([
            'type'    => 'item',
            'index'   => $index,
            'email'   => $email,
            'status'  => 'error',
            'message' => 'Exceção PHPMailer: ' . $e->getMessage()
        ]);
    }
}

$mail->smtpClose();

// evento final
sendEvent([
    'type'   => 'done',
    'total'  => $total,
    'sent'   => $sent,
    'failed' => $failed
]);
